from django.db import models
from django.contrib.auth.models import AbstractUser
from .managers import UserManager

# Create your models here.

class CustomUser(AbstractUser):
    username=None
    phone_number=models.CharField(max_length=20,unique=True)
    email=models.EmailField(unique=True)    
    user_bio=models.CharField(max_length=100)
    USERNAME_FIELD= 'phone_number'
    REQUIRED_FIELDS=[]

    objects= UserManager()




