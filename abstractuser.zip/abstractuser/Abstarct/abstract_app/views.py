from django.shortcuts import render

from .models import CustomUser

# Create your views here.
# def registeer(request):
#     # if request.method =='POST':
        
#     return render (request,"register.html")
